/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  LogIn, 
  Home, 
  Search, 
  RefreshCw, 
  Database, 
  ArrowRight, 
  ArrowDown,
  Bell,
  CheckCircle2,
  Users,
  MapPin,
  Camera,
  CloudLightning,
  Smartphone
} from 'lucide-react';
import { motion } from 'motion/react';

export default function ProjectFlow() {
  const FlowCard = ({ icon: Icon, title, desc, color, accentColor }: any) => (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className={`p-4 rounded-3xl bg-white border-2 border-slate-100 shadow-md flex flex-col items-center text-center gap-2 w-full`}
    >
      <div className={`p-4 rounded-2xl ${color} text-white shadow-lg ${accentColor}`}>
        <Icon size={28} />
      </div>
      <h4 className="text-[11px] font-black uppercase tracking-tight text-slate-900 mt-2">{title}</h4>
      <p className="text-[9px] font-bold text-slate-400 leading-tight px-2">{desc}</p>
    </motion.div>
  );

  const ConnectionArrow = ({ vertical = false, label, animate = false }: { vertical?: boolean, label?: string, animate?: boolean }) => (
    <div className={`flex ${vertical ? 'flex-col min-h-[40px]' : 'flex-row min-w-[30px] flex-1'} items-center justify-center gap-2`}>
      <div className={`relative ${vertical ? 'h-full w-1' : 'w-full h-1'} bg-slate-100 rounded-full overflow-hidden`}>
        {animate && (
          <motion.div 
            animate={vertical ? { y: [-20, 40] } : { x: [-20, 60] }}
            transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
            className={`absolute ${vertical ? 'w-full h-4 top-0' : 'h-full w-4 left-0'} bg-primary/30`}
          />
        )}
      </div>
      {label && <span className="text-[8px] font-black uppercase tracking-widest text-slate-300 whitespace-nowrap">{label}</span>}
      <ArrowRight size={14} className={`${vertical ? 'rotate-90' : ''} text-slate-200`} />
    </div>
  );

  return (
    <div className="flex flex-col gap-10 py-6 px-4 overflow-y-auto scrollbar-hide bg-slate-50 min-h-full pb-20">
      <header className="text-center">
        <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-3">
          <Smartphone size={14} />
          <span className="text-[10px] font-black uppercase tracking-widest text-primary">System Blueprint</span>
        </div>
        <h2 className="text-2xl font-black text-slate-900 tracking-tight italic">GRAMAYATRI</h2>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mt-1">Community Transit Protocol</p>
      </header>

      {/* Entry Layer */}
      <section className="flex flex-col gap-6">
        <div className="flex items-center gap-3">
          <FlowCard 
            icon={LogIn} 
            title="Entrance" 
            desc="Secure Mobile PIN/OTP" 
            color="bg-primary"
            accentColor="shadow-primary/20"
          />
          <ConnectionArrow label="Auth" />
          <FlowCard 
            icon={Home} 
            title="Dashboard" 
            desc="The Hub of Operations" 
            color="bg-amber-400"
            accentColor="shadow-amber-100"
          />
        </div>
      </section>

      <div className="flex justify-center -my-4">
        <ConnectionArrow vertical animate label="Selection" />
      </div>

      {/* Action Layer */}
      <div className="grid grid-cols-2 gap-4">
        {/* Module A: Passenger */}
        <div className="flex flex-col items-center gap-4">
            <div className="px-3 py-1 bg-blue-100 rounded-full text-[8px] font-black text-blue-600 uppercase tracking-widest">Consumer Layer</div>
            <FlowCard 
              icon={Search} 
              title="Track" 
              desc="Select Route & Village" 
              color="bg-blue-600"
              accentColor="shadow-blue-100"
            />
            <ConnectionArrow vertical animate />
            <FlowCard 
              icon={Bell} 
              title="ETA Live" 
              desc="Real-time Wait Clock" 
              color="bg-indigo-600"
              accentColor="shadow-indigo-100"
            />
        </div>

        {/* Module B: Contributor */}
        <div className="flex flex-col items-center gap-4">
            <div className="px-3 py-1 bg-emerald-100 rounded-full text-[8px] font-black text-emerald-600 uppercase tracking-widest">Provider Layer</div>
            <FlowCard 
              icon={RefreshCw} 
              title="Update" 
              desc="Report Bus Presence" 
              color="bg-emerald-600"
              accentColor="shadow-emerald-100"
            />
            <ConnectionArrow vertical animate />
            <FlowCard 
              icon={Camera} 
              title="Verify" 
              desc="Proof of Visual Contact" 
              color="bg-emerald-800"
              accentColor="shadow-emerald-900/20"
            />
        </div>
      </div>

      {/* Real-time Sync Engine */}
      <div className="relative p-1 bg-gradient-to-br from-slate-800 to-slate-900 rounded-[3rem] shadow-2xl border-b-8 border-slate-950">
        <div className="p-8 flex flex-col items-center gap-6 text-center">
            <div className="flex items-center gap-4 mb-2">
                <div className="p-3 bg-primary rounded-2xl shadow-xl shadow-primary/20">
                  <Database className="text-white" size={32} />
                </div>
                <div className="flex flex-col items-start">
                  <h3 className="text-lg font-black text-white italic tracking-widest">FIREBASE CLOUD</h3>
                  <div className="flex items-center gap-2">
                    <CloudLightning size={12} className="text-amber-400" />
                    <span className="text-[8px] font-bold text-amber-100 uppercase tracking-tight">Real-time Reactive Engine</span>
                  </div>
                </div>
            </div>

            <div className="grid grid-cols-2 gap-6 w-full">
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-primary">
                  <RefreshCw size={20} className="animate-spin" />
                </div>
                <span className="text-[7px] font-black text-slate-400 uppercase leading-tight tracking-widest">Instant Data<br/>Propagation</span>
              </div>
              <div className="flex flex-col items-center gap-2">
                <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-amber-400">
                  <CheckCircle2 size={20} />
                </div>
                <span className="text-[7px] font-black text-slate-400 uppercase leading-tight tracking-widest">Atomic<br/>Write-Guard</span>
              </div>
            </div>

            <div className="w-full h-px bg-white/5 mt-2" />

            <p className="text-[8px] font-bold text-slate-500 uppercase tracking-[0.2em] leading-relaxed italic">
              "One Passive Report Updates Entire Village Corridor"
            </p>
        </div>
      </div>

      <footer className="text-center pt-2">
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 rounded-full mb-2">
          <Users size={12} className="text-slate-400" />
          <span className="text-[8px] font-black uppercase text-slate-500 tracking-tighter">Community Consensus Required</span>
        </div>
        <p className="text-[7px] font-bold text-slate-300 uppercase tracking-tighter">
          Academic Flow Representation v2.0
        </p>
      </footer>
    </div>
  );
}
