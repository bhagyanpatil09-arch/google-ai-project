/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  User, 
  Bell, 
  Languages, 
  Shield, 
  HelpCircle, 
  LogOut, 
  ChevronRight,
  Database,
  Smartphone,
  Users,
  Award
} from 'lucide-react';
import Button from '../components/ui/Button';
import { auth } from '../lib/firebase';
import { userService } from '../lib/services';

interface SettingsProps {
  onEditProfile: () => void;
}

export default function Settings({ onEditProfile }: SettingsProps) {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      if (auth.currentUser) {
        const data = await userService.getProfile(auth.currentUser.uid);
        setProfile(data);
      }
      setLoading(false);
    };
    fetchProfile();
  }, []);

  const SettingItem = ({ icon: Icon, title, desc, color, onClick }: any) => (
    <button 
      onClick={onClick}
      className="w-full flex items-center gap-4 p-4 bg-white rounded-3xl border-2 border-slate-50 hover:border-primary/20 transition-all group shadow-sm"
    >
      <div className={`p-3 rounded-2xl ${color} bg-opacity-10 text-opacity-100 flex items-center justify-center`}>
        <Icon size={20} className={color.replace('bg-', 'text-')} />
      </div>
      <div className="flex-1 text-left">
        <h4 className="text-[11px] font-black text-slate-900 uppercase tracking-tight">{title}</h4>
        <p className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">{desc}</p>
      </div>
      <ChevronRight size={16} className="text-slate-300 group-hover:text-primary transition-colors" />
    </button>
  );

  const isAdmin = profile?.role === 'admin';

  return (
    <div className="flex flex-col gap-6 h-full pb-10">
      {/* Profile Header */}
      <section className="bg-gradient-to-br from-primary to-primary-dark p-6 rounded-[2.5rem] text-white shadow-xl relative overflow-hidden">
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
        <div className="relative flex items-center gap-4">
          <div className="w-16 h-16 rounded-3xl bg-white/20 backdrop-blur-md flex items-center justify-center border-2 border-white/30 shadow-inner">
            <User size={32} className="text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-black italic tracking-tight">{profile?.name || 'Sunil Kumar'}</h3>
            <div className="flex items-center gap-2 bg-emerald-500/20 px-2 py-0.5 rounded-full mt-1 border border-emerald-500/30 w-fit">
              <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div>
              <span className="text-[8px] font-black uppercase tracking-widest text-emerald-100">
                {isAdmin ? 'System Admin' : 'Top Contributor'}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Role Card */}
      <div className="bg-slate-900 p-6 rounded-[2.5rem] text-white flex items-center justify-between shadow-xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-amber-400">
            <Award size={24} />
          </div>
          <div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Global Status</p>
            <h4 className="text-lg font-black capitalize">{profile?.role || 'User'}</h4>
          </div>
        </div>
        <div className="text-right">
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Points</p>
          <p className="text-lg font-black text-amber-400">1,240</p>
        </div>
      </div>

      {/* Settings Groups */}
      <div className="flex flex-col gap-4">
        <h5 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.3em] px-2">Account & Safety</h5>
        <div className="flex flex-col gap-2">
          <SettingItem 
            icon={User} 
            title="Update Profile" 
            desc="Name, Phone & Village" 
            color="bg-blue-500" 
            onClick={onEditProfile}
          />
          {isAdmin && (
            <SettingItem 
              icon={Users} 
              title="Manage Users" 
              desc="Approve roles & moderator access" 
              color="bg-purple-500" 
            />
          )}
          <SettingItem 
            icon={Shield} 
            title="Privacy" 
            desc="Identity & Data Control" 
            color="bg-indigo-500" 
          />
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <h5 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.3em] px-2">Preferences</h5>
        <div className="flex flex-col gap-2">
          <SettingItem 
            icon={Languages} 
            title="App Language" 
            desc="English / ಕನ್ನಡ / हिन्दी" 
            color="bg-amber-500" 
          />
          <SettingItem 
            icon={Bell} 
            title="Notifications" 
            desc="Route & Bus Alerts" 
            color="bg-rose-500" 
          />
        </div>
      </div>

      <div className="flex flex-col gap-4">
        <h5 className="text-[9px] font-black text-slate-400 uppercase tracking-[0.3em] px-2">Support</h5>
        <div className="flex flex-col gap-2">
          <SettingItem 
            icon={HelpCircle} 
            title="Help Center" 
            desc="Tutorials & Support" 
            color="bg-emerald-500" 
          />
          <button 
            onClick={() => auth.signOut()}
            className="w-full flex items-center justify-center gap-2 p-4 text-rose-500 font-black text-[11px] uppercase tracking-[0.2em] bg-rose-50 rounded-3xl border-2 border-rose-100/50 mt-2"
          >
            <LogOut size={16} /> Sign Out
          </button>
        </div>
      </div>

      <div className="mt-auto pt-6 flex flex-col gap-4">
        <div className="p-4 bg-slate-50 rounded-3xl border-2 border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-3">
             <Smartphone size={16} className="text-slate-400" />
             <div className="flex flex-col">
               <span className="text-[8px] font-black text-slate-500 uppercase">App Version</span>
               <span className="text-[10px] font-black text-slate-900">v2.5.4-beta</span>
             </div>
          </div>
          <Database size={16} className="text-slate-300" />
        </div>
      </div>
    </div>
  );
}
