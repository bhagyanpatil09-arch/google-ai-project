/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CheckCircle2, Home } from 'lucide-react';
import Button from '../components/ui/Button';

interface ConfirmationProps {
  onDone: () => void;
}

export default function Confirmation({ onDone }: ConfirmationProps) {
  return (
    <div className="flex flex-col items-center justify-center h-full gap-8 text-center">
      <div className="bg-emerald-100 p-8 rounded-full border-b-8 border-emerald-200">
        <CheckCircle2 size={120} className="text-emerald-600" />
      </div>
      
      <div>
        <h2 className="text-4xl font-black text-slate-900 mb-2">THANK YOU!</h2>
        <p className="text-slate-500 font-bold uppercase tracking-widest text-sm">
          Your update helps everyone in the village.
        </p>
      </div>

      <div className="w-full mt-12">
        <Button 
          size="xl" 
          variant="primary" 
          icon={<Home size={20} />}
          onClick={onDone}
        >
          Back to Home
        </Button>
      </div>
    </div>
  );
}
