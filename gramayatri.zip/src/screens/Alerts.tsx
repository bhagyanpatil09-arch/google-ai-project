/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AlertCircle, Clock, XCircle, Info, User } from 'lucide-react';
import Button from '../components/ui/Button';
import { busService } from '../lib/services';
import { Alert } from '../types';

export default function Alerts() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [reporterName, setReporterName] = useState('');

  useEffect(() => {
    return busService.subscribeToAlerts((newAlerts) => {
      setAlerts(newAlerts);
    });
  }, []);

  const handleReport = async (type: Alert['type'], title: string) => {
    if (!reporterName.trim()) {
      alert("Please enter your name to report");
      return;
    }
    try {
      await busService.submitAlert(type, title, `Community reported ${type} issue.`, reporterName);
      alert("Reported successfully!");
    } catch (e) {
      alert("Failed to report.");
    }
  };

  return (
    <div className="flex flex-col gap-6 overflow-y-auto pb-10 scrollbar-hide">
      <div className="bg-red-500 p-6 rounded-3xl text-white shadow-xl text-center">
        <div className="text-[10px] font-bold uppercase tracking-[0.2em] opacity-80 mb-1">Attention</div>
        <h2 className="text-xl font-black">Community Alerts</h2>
      </div>

      <div className="flex flex-col gap-3">
        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest px-2 flex items-center gap-2">
           <User size={12} /> Your Name
        </label>
        <input 
          type="text"
          placeholder="e.g. Sunil K."
          value={reporterName}
          onChange={(e) => setReporterName(e.target.value)}
          className="w-full p-4 text-sm font-black bg-white border-[3px] border-slate-100 rounded-xl outline-none focus:border-red-500 transition-all placeholder:text-slate-200"
        />
      </div>

      <div className="flex flex-col gap-4">
        {alerts.length > 0 ? alerts.map((alert) => (
          <div key={alert.id} className={`
            p-5 rounded-2xl border-b-4 flex flex-col gap-1
            ${alert.type === 'cancel' ? 'bg-red-50 border-red-200' : 'bg-amber-50 border-amber-200'}
          `}>
            <div className="flex justify-between items-center mb-1">
              <h4 className={`text-xs font-black uppercase tracking-tight ${alert.type === 'cancel' ? 'text-red-700' : 'text-amber-800'}`}>
                {alert.type === 'cancel' || alert.type === 'breakdown' ? '⚠️ ' : '⏳ '}{alert.title}
              </h4>
              <span className="text-[8px] font-black opacity-40 uppercase">
                {Math.floor((Date.now() - alert.timestamp) / 60000)}m ago
              </span>
            </div>
            <p className={`text-[10px] font-bold leading-tight ${alert.type === 'cancel' ? 'text-red-600' : 'text-amber-700'}`}>
              {alert.desc}
            </p>
            <div className="text-[8px] font-black uppercase opacity-40 mt-1">
               Source: {alert.updatedBy}
            </div>
          </div>
        )) : (
          <div className="p-8 text-center text-slate-300 font-bold uppercase text-[10px] tracking-widest bg-slate-50 rounded-3xl border-2 border-dashed border-slate-100">
            No active alerts at this time.
          </div>
        )}
      </div>

      <div className="mt-4 p-5 bg-slate-900 rounded-[2rem] text-white flex flex-col gap-4 shadow-xl border-b-8 border-slate-950">
        <h4 className="text-[10px] font-black text-amber-400 flex items-center gap-2 tracking-[0.3em] justify-center">
           REPORT AN ISSUE
        </h4>
        <div className="grid grid-cols-2 gap-2">
          <Button 
            size="lg" 
            onClick={() => handleReport('delay', 'Bus Delayed')}
            className="bg-white/10 text-white !h-14 text-[9px] !p-2 !shadow-none border border-white/20 active:bg-amber-500 active:text-amber-950"
          >
            Report Delay
          </Button>
          <Button 
            size="lg" 
            onClick={() => handleReport('breakdown', 'Bus Breakdown')}
            className="bg-white/10 text-white !h-14 text-[9px] !p-2 !shadow-none border border-white/20 active:bg-red-500 active:text-white"
          >
            Breakdown
          </Button>
        </div>
        <Button 
            size="lg" 
            onClick={() => handleReport('cancel', 'Bus Cancelled')}
            className="bg-red-600 text-white !h-14 text-[9px] !p-2 border-b-4 border-red-800"
          >
            Report Cancellation
          </Button>
      </div>

      <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 italic text-[9px] text-blue-700 text-center font-bold">
        User-reported alerts are shared instantly with all passengers. 🤝
      </div>
    </div>
  );
}
