/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  User, 
  Share2, 
  Info, 
  MapPin, 
  ArrowRight, 
  Users, 
  Gauge, 
  Cloudy, 
  Armchair, 
  Clock, 
  ChevronRight,
  TrendingUp,
  Map as MapIcon,
  Zap,
  Bus as BusIcon
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Button from '../components/ui/Button';
import { busService } from '../lib/services';
import { BusUpdate, BusStatus } from '../types';
import { STOPS_BASE } from '../constants';

interface LiveStatusProps {
  stopName: string;
  onUpdateClick?: () => void;
}

export default function LiveStatus({ stopName, onUpdateClick }: LiveStatusProps) {
  const [updates, setUpdates] = useState<BusUpdate[]>([]);
  const targetStop = STOPS_BASE.find(s => s.name === stopName) || STOPS_BASE[0];

  useEffect(() => {
    return busService.subscribeToUpdates((newUpdates) => {
      setUpdates(newUpdates);
    });
  }, []);

  const latestUpdate = updates[0] || null;

  // Use the sample data if no real update exists for presentation purposes
  const displayData = latestUpdate || {
    stopId: 'lakshmipura',
    status: BusStatus.COMING,
    timestamp: Date.now() - 300000,
    updatedBy: 'Anand K.',
    crowdLevel: 'medium',
    roadCondition: 'good',
    weather: 'clear',
    seating: 'available'
  };

  const currentStopObj = STOPS_BASE.find(s => s.id === displayData.stopId) || STOPS_BASE[2];

  const getStatusColor = (status: BusStatus) => {
    switch (status) {
      case BusStatus.COMING: return 'bg-emerald-500';
      case BusStatus.DELAYED: return 'bg-amber-500';
      case BusStatus.CANCELLED: return 'bg-rose-500';
      default: return 'bg-blue-500';
    }
  };

  return (
    <div className="flex flex-col gap-6 h-full pb-10 overflow-y-auto scrollbar-hide">
      {/* Header Section */}
      <div className="flex items-center justify-between px-2 pt-2">
        <div>
          <h1 className="text-2xl font-black text-slate-900 leading-none">Live Bus Status</h1>
          <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mt-1 flex items-center gap-1">
            <Zap size={10} className="fill-emerald-600" /> Community Updates
          </p>
        </div>
        <div className="flex gap-2">
          <button className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-600 active:scale-95 transition-transform">
            <Share2 size={18} />
          </button>
        </div>
      </div>

      {/* Main Bus Info Card */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-[2.5rem] p-6 shadow-xl shadow-slate-200/50 border border-slate-100 relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full -mr-16 -mt-16 z-0" />
        
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center text-emerald-600">
                <BusIcon size={24} />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900">Morning Village Bus</h3>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Route #402 Rural Express</p>
              </div>
            </div>
            <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase text-white shadow-lg ${getStatusColor(displayData.status as BusStatus)}`}>
              {displayData.status}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-50 p-4 rounded-3xl">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Current Location</p>
              <div className="flex items-center gap-1.5">
                <MapPin size={12} className="text-rose-500" />
                <span className="text-sm font-black text-slate-900">{currentStopObj.name}</span>
              </div>
            </div>
            <div className="bg-slate-50 p-4 rounded-3xl">
              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Last Update</p>
              <div className="flex items-center gap-1.5">
                <Clock size={12} className="text-blue-500" />
                <span className="text-sm font-black text-slate-900">
                  {new Date(displayData.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Route Display Section */}
      <section className="bg-slate-900 p-6 rounded-[2.5rem] shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Route Tracker</h4>
          <div className="flex items-center gap-1 text-[9px] font-bold text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded-full">
            <TrendingUp size={10} /> In Transit
          </div>
        </div>
        
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide pb-2">
          {STOPS_BASE.map((stop, i) => (
            <React.Fragment key={stop.id}>
              <div className="flex flex-col items-center gap-2">
                <div className={`w-3 h-3 rounded-full border-2 ${stop.id === displayData.stopId ? 'bg-white border-white' : 'bg-slate-700 border-slate-600'}`} />
                <span className={`text-[8px] font-black uppercase whitespace-nowrap tracking-tighter ${stop.id === displayData.stopId ? 'text-white' : 'text-slate-500'}`}>
                  {stop.name}
                </span>
              </div>
              {i < STOPS_BASE.length - 1 && (
                <div className="h-[1px] w-8 bg-slate-700 shrink-0" />
              )}
            </React.Fragment>
          ))}
        </div>
      </section>

      {/* Advanced Community Updates Grid */}
      <section className="flex flex-col gap-3">
        <div className="flex items-center justify-between px-2">
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Real-time Feedback</h4>
          <span className="text-[8px] font-bold text-blue-500 bg-blue-50 px-2 py-1 rounded-lg">Verified by 12 Users</span>
        </div>

        <div className="grid grid-cols-2 gap-3">
          {/* Seating */}
          <div className="bg-emerald-50 rounded-3xl p-4 border border-emerald-100 flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-emerald-600 shadow-sm">
              <Armchair size={20} />
            </div>
            <div>
              <p className="text-[8px] font-black text-emerald-600/60 uppercase tracking-widest">Seating</p>
              <p className="text-xs font-black text-emerald-900 capitalize">{displayData.seating?.replace('_', ' ') || 'Seats Avail.'}</p>
            </div>
          </div>

          {/* Crowd */}
          <div className="bg-blue-50 rounded-3xl p-4 border border-blue-100 flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-blue-600 shadow-sm">
              <Users size={20} />
            </div>
            <div>
              <p className="text-[8px] font-black text-blue-600/60 uppercase tracking-widest">Crowd</p>
              <p className="text-xs font-black text-blue-900 capitalize">{displayData.crowdLevel || 'Low'}</p>
            </div>
          </div>

          {/* Road */}
          <div className="bg-amber-50 rounded-3xl p-4 border border-amber-100 flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-amber-600 shadow-sm">
              <Gauge size={20} />
            </div>
            <div>
              <p className="text-[8px] font-black text-amber-600/60 uppercase tracking-widest">Road Cond.</p>
              <p className="text-xs font-black text-amber-900 capitalize">{displayData.roadCondition || 'Smooth'}</p>
            </div>
          </div>

          {/* Weather */}
          <div className="bg-sky-50 rounded-3xl p-4 border border-sky-100 flex items-center gap-3">
            <div className="w-10 h-10 bg-white rounded-2xl flex items-center justify-center text-sky-600 shadow-sm">
              <Cloudy size={20} />
            </div>
            <div>
              <p className="text-[8px] font-black text-sky-600/60 uppercase tracking-widest">Weather</p>
              <p className="text-xs font-black text-sky-900 capitalize">{displayData.weather || 'Sunny'}</p>
            </div>
          </div>
        </div>
      </section>

      {/* ETA Details Section */}
      <section className="bg-white rounded-[2.5rem] p-6 border border-slate-100 shadow-sm">
        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Estimated Arrivals</h4>
        <div className="flex flex-col gap-4">
          {STOPS_BASE.filter(s => s.order > currentStopObj.order).slice(0, 2).map((stop, idx) => (
            <div key={stop.id} className="flex items-center justify-between pb-4 border-b border-slate-50 last:border-0 last:pb-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400 text-xs font-bold">
                  {idx + 1}
                </div>
                <div>
                  <h5 className="text-xs font-black text-slate-900">{stop.name}</h5>
                  <p className="text-[9px] font-bold text-slate-400 uppercase">Next Destination</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-black text-emerald-600">{10 + (idx + 1) * 10}:{(idx + 1) * 5 + 10} AM</p>
                <p className="text-[8px] font-bold text-slate-400 uppercase">On Time</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <div className="mt-auto px-2">
        <Button 
          onClick={onUpdateClick}
          className="bg-slate-900 shadow-xl shadow-slate-200 py-6 rounded-[2rem]"
        >
          <div className="flex items-center justify-center gap-3 w-full">
            <span className="bg-white/10 p-1.5 rounded-xl"><ChevronRight size={18} /></span>
            <span className="uppercase tracking-[0.2em] font-black text-[11px]">Update Current Info</span>
          </div>
        </Button>
      </div>

      <div className="flex justify-center items-center gap-2 text-slate-300 pb-2">
        <Info size={12} />
        <span className="text-[10px] font-bold uppercase tracking-tighter">Community Powered Live Sync v2.0</span>
      </div>
    </div>
  );
}

