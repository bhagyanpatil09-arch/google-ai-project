/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Database, Code, Clock, Bus, MapPin, CheckCircle2, AlertTriangle } from 'lucide-react';
import { STOPS_BASE } from '../constants';
import Button from '../components/ui/Button';

export default function DemoDataset() {
  const currentUpdate = {
    busName: "Grama-Vahini (Route #42)",
    lastSpotted: "Ramnagar",
    timestamp: "10:15 AM",
    status: "COMING",
    reporter: "Sunil Kumar (Passenger)"
  };

  const firebaseJSON = {
    id: "upd_001",
    busId: "gv_42_rural",
    stopId: "ramnagar",
    status: "COMING",
    timestamp: 1714714500000,
    updatedBy: "Sunil Kumar",
    coordinates: { lat: 12.9816, lng: 77.6046 }
  };

  return (
    <div className="flex flex-col gap-8 py-8 px-5 overflow-y-auto scrollbar-hide bg-slate-50 min-h-full pb-20">
      <header className="text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-100 text-amber-700 rounded-full mb-3">
          <Database size={14} />
          <span className="text-[10px] font-black uppercase tracking-widest">Presentation Kit</span>
        </div>
        <h2 className="text-2xl font-black text-slate-900 tracking-tight italic">REAL-TIME DATA MODEL</h2>
        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mt-1">Realistic Rural Transit Scenario</p>
      </header>

      {/* Live Context Card */}
      <div className="bg-white p-6 rounded-[2.5rem] border-b-8 border-slate-200 shadow-xl">
        <div className="flex items-center gap-4 mb-4">
          <div className="p-4 bg-amber-400 rounded-2xl text-white shadow-lg shadow-amber-100">
            <Bus size={32} />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900">{currentUpdate.busName}</h3>
            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none mt-1">Verified by Community</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mt-6">
          <div className="p-4 bg-slate-50 rounded-2xl border-2 border-slate-100">
             <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Status</p>
             <span className="font-black text-emerald-600 text-sm italic">{currentUpdate.status}</span>
          </div>
          <div className="p-4 bg-slate-50 rounded-2xl border-2 border-slate-100">
             <p className="text-[8px] font-black text-slate-400 uppercase mb-1">Reported</p>
             <span className="font-black text-slate-900 text-sm">{currentUpdate.timestamp}</span>
          </div>
        </div>
      </div>

      {/* ETA Table */}
      <section className="flex flex-col gap-4">
        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] px-2">Route Timeline (ETA)</h4>
        <div className="bg-white rounded-[2rem] border-2 border-slate-100 overflow-hidden shadow-md">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b-2 border-slate-100">
              <tr>
                <th className="px-5 py-4 text-[9px] font-black text-slate-500 uppercase">Stop</th>
                <th className="px-5 py-4 text-[9px] font-black text-slate-500 uppercase text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y-2 divide-slate-100">
              {STOPS_BASE.map((stop) => {
                const isCurrent = stop.name === currentUpdate.lastSpotted;
                const isPassed = stop.order < 2;
                
                return (
                  <tr key={stop.id} className={isCurrent ? 'bg-amber-50/50' : ''}>
                    <td className="px-5 py-4">
                      <div className="flex flex-col">
                        <span className={`text-[11px] font-black uppercase tracking-tight ${isPassed ? 'text-slate-300 line-through' : 'text-slate-900'}`}>
                          {stop.name}
                        </span>
                        {isCurrent && <span className="text-[7px] font-black text-amber-600 uppercase tracking-tighter">Current Location</span>}
                      </div>
                    </td>
                    <td className="px-5 py-4 text-right">
                       {isPassed ? (
                         <div className="inline-flex items-center gap-1 text-emerald-500">
                           <CheckCircle2 size={10} />
                           <span className="text-[9px] font-black uppercase italic">Passed</span>
                         </div>
                       ) : isCurrent ? (
                         <span className="text-[10px] font-black text-amber-500 uppercase animate-pulse">Live</span>
                       ) : (
                         <div className="inline-flex items-center gap-1 text-slate-400">
                           <Clock size={10} />
                           <span className="text-[11px] font-black text-slate-900">{stop.averageTravelMinutes}m</span>
                         </div>
                       )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* JSON Schema Section */}
      <section className="flex flex-col gap-4">
        <div className="flex items-center gap-2 px-2">
          <Code size={16} className="text-primary" />
          <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Firebase Data Snapshot</h4>
        </div>
        <div className="bg-slate-900 p-6 rounded-[2rem] border-b-8 border-slate-950 shadow-2xl overflow-x-auto relative group">
          <div className="absolute top-4 right-4 text-[8px] font-black text-emerald-500/50 uppercase tracking-widest group-hover:text-emerald-500 transition-colors">实时数据</div>
          <pre className="text-[10px] font-mono text-emerald-400/90 leading-relaxed">
            {JSON.stringify(firebaseJSON, null, 2)}
          </pre>
          <div className="mt-6 flex justify-between items-center opacity-50">
             <span className="text-[7px] font-bold text-slate-500 uppercase">Collection: /updates/upd_001</span>
             <Database size={10} className="text-slate-500" />
          </div>
        </div>
      </section>

      <div className="bg-indigo-50 p-6 rounded-3xl border-2 border-indigo-100 flex flex-col gap-2 shadow-sm italic">
        <div className="flex items-center gap-2 text-indigo-700">
          <AlertTriangle size={14} />
          <h5 className="text-[10px] font-black uppercase tracking-widest">Logic Constraint</h5>
        </div>
        <p className="text-[9px] font-bold text-indigo-900 leading-relaxed uppercase tracking-tighter">
          ETA is calculated by summing "averageTravelMinutes" for all remaining stops in sequence, subtracting time since last community report.
        </p>
      </div>

      <footer className="mt-4 text-center">
        <p className="text-[8px] font-black text-slate-300 uppercase tracking-[0.4em]">Integrated Presentation Layer v2.1</p>
      </footer>
    </div>
  );
}
