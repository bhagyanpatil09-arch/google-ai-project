/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { Camera, Clock, CheckCircle2, User, X, Image as ImageIcon, Trash2, Users, MapPin, Gauge } from 'lucide-react';
import Button from '../components/ui/Button';
import { BusStatus } from '../types';
import { busService } from '../lib/services';
import { STOPS_BASE } from '../constants';
import { motion, AnimatePresence } from 'motion/react';

interface LiveUpdateProps {
  onComplete: () => void;
}

export default function LiveUpdate({ onComplete }: LiveUpdateProps) {
  const [selectedStatus, setSelectedStatus] = useState<BusStatus>(BusStatus.COMING);
  const [selectedStop, setSelectedStop] = useState(STOPS_BASE[1].id);
  const [crowdLevel, setCrowdLevel] = useState<'low' | 'medium' | 'high' | undefined>();
  const [roadCondition, setRoadCondition] = useState<'good' | 'average' | 'poor' | undefined>();
  const [weather, setWeather] = useState<'clear' | 'rainy' | 'foggy' | undefined>();
  const [seating, setSeating] = useState<'available' | 'standing_only' | 'full' | undefined>();
  const [reporterName, setReporterName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageCapture = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCapturedImage(reader.result as string);
        setShowPreview(true);
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerCamera = () => {
    fileInputRef.current?.click();
  };

  const handleSubmit = async () => {
    if (!reporterName.trim()) {
      alert("Please enter your name for the community update");
      return;
    }

    setIsSubmitting(true);
    try {
      await busService.submitUpdate(selectedStop, selectedStatus, reporterName, {
        crowdLevel,
        roadCondition,
        weather,
        seating
      });
      setIsSuccess(true);
      setTimeout(() => {
        onComplete();
      }, 2000);
    } catch (error) {
      alert('Failed to update. Please try again.');
    } finally {
      setIsSubmitting(false);
      setShowPreview(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center h-full gap-6 p-8 text-center animate-in fade-in zoom-in duration-500">
        <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 shadow-xl shadow-emerald-100">
          <CheckCircle2 size={48} strokeWidth={3} />
        </div>
        <div className="flex flex-col gap-2">
          <h2 className="text-2xl font-black text-slate-900 leading-tight">Macha, Updated!</h2>
          <p className="text-sm font-bold text-slate-500 max-w-[200px] mx-auto uppercase tracking-wider">Your neighbors will be grateful for this ping.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 h-full relative overflow-y-auto scrollbar-hide pb-10">
      {/* Hidden File Input for Camera */}
      <input 
        type="file"
        accept="image/*"
        capture="environment"
        ref={fileInputRef}
        onChange={handleImageCapture}
        className="hidden"
      />

      <div className="bg-emerald-600 p-6 rounded-3xl text-white shadow-xl flex flex-col gap-1 items-center">
        <div className="text-[9px] font-black uppercase tracking-[0.3em] opacity-80">Community Node</div>
        <h2 className="text-xl font-black">Share Live Bus Info</h2>
        <div className="flex gap-1 mt-2">
          {[1, 2, 3].map(i => <div key={i} className="w-1.5 h-1.5 rounded-full bg-white/30" />)}
        </div>
      </div>

      {/* Reporter Info */}
      <section className="flex flex-col gap-2">
        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 flex items-center justify-between">
           <div className="flex items-center gap-1.5"><User size={10} /> Reporter Identity</div>
           <span className="text-[8px] opacity-60">Required</span>
        </label>
        <input 
          type="text"
          placeholder="your name (e.g. Anand K.)"
          value={reporterName}
          onChange={(e) => setReporterName(e.target.value)}
          className="w-full p-4 text-xs font-black bg-white border-[3px] border-slate-100 rounded-2xl outline-none focus:border-emerald-500 transition-all placeholder:text-slate-200 shadow-sm"
        />
      </section>

      {/* Location Picker */}
      <section className="flex flex-col gap-3">
        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2 flex items-center gap-1.5">
           <MapPin size={10} /> Current Landmark
        </label>
        <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide -mx-2 px-2">
           {STOPS_BASE.map((stop) => (
             <button
               key={stop.id}
               onClick={() => setSelectedStop(stop.id)}
               className={`shrink-0 px-4 py-3 rounded-xl font-black text-[10px] uppercase tracking-wider border-2 transition-all ${selectedStop === stop.id ? 'bg-slate-900 border-slate-900 text-white shadow-lg' : 'bg-white border-slate-100 text-slate-400 font-bold'}`}
             >
               {stop.name}
             </button>
           ))}
        </div>
      </section>

      <div className="flex flex-col items-center justify-center py-2 relative">
        <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none">
           <div className="w-64 h-64 border-2 border-slate-900 rounded-full" />
           <div className="absolute w-48 h-48 border-2 border-slate-900 rounded-full" />
        </div>
        
        <button 
          onClick={handleSubmit}
          disabled={isSubmitting}
          className={`
            w-44 h-44 rounded-full border-[10px] flex flex-col items-center justify-center gap-2 transform active:scale-95 transition-all shadow-2xl z-10
            ${isSubmitting ? 'bg-slate-100 border-slate-200 text-slate-400' : 'bg-white border-emerald-500 text-emerald-600 shadow-emerald-100'}
          `}
        >
           <motion.div 
             animate={isSubmitting ? { scale: [1, 1.2, 1], opacity: [1, 0.5, 1] } : {}}
             transition={{ repeat: Infinity, duration: 1 }}
             className="text-5xl"
           >
             📡
           </motion.div>
           <div className="font-black text-[11px] uppercase tracking-tighter">
             {isSubmitting ? 'SUBMITTING...' : 'PING LOCATION'}
           </div>
        </button>

        <button
          onClick={triggerCamera}
          className="absolute bottom-2 right-1/2 translate-x-16 bg-emerald-500 p-4 rounded-2xl shadow-xl border-4 border-white text-white active:scale-90 transition-transform z-20"
        >
          <Camera size={20} />
        </button>
      </div>

      {/* Quick Status */}
      <div className="grid grid-cols-3 gap-2">
        {(Object.values(BusStatus) as BusStatus[])
          .filter(s => [BusStatus.COMING, BusStatus.ON_BOARD, BusStatus.PASSED].includes(s))
          .map((status) => {
            const isActive = selectedStatus === status;
            const labels: any = {
              [BusStatus.COMING]: { label: 'Coming', icon: '🚍' },
              [BusStatus.ON_BOARD]: { label: 'On Bus', icon: '🙋' },
              [BusStatus.PASSED]: { label: 'Passed', icon: '💨' }
            };
            return (
              <button 
                key={status}
                onClick={() => setSelectedStatus(status)}
                className={`p-3 rounded-xl flex flex-col items-center gap-1 border-2 transition-all ${isActive ? 'bg-emerald-50 border-emerald-500 text-emerald-700' : 'bg-white border-slate-50 text-slate-300'}`}
              >
                <span className="text-xl opacity-80">{labels[status].icon}</span>
                <span className="text-[10px] font-black uppercase tracking-tighter">{labels[status].label}</span>
              </button>
            );
          })}
      </div>

      {/* Extra Details */}
      <div className="bg-slate-50 p-6 rounded-[2.5rem] flex flex-col gap-6 -mx-2 border border-slate-100">
        <section className="flex flex-col gap-3">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
             <Users size={10} /> Passenger Density
          </label>
          <div className="grid grid-cols-3 gap-2">
             {[
               { id: 'low', label: 'Seats', icon: '🪑' },
               { id: 'medium', label: 'Crowded', icon: '🧍' },
               { id: 'high', label: 'Full', icon: '🥵' }
             ].map(level => (
               <button
                 key={level.id}
                 onClick={() => setCrowdLevel(level.id as any)}
                 className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${crowdLevel === level.id ? 'bg-white border-blue-500 text-blue-600 shadow-sm' : 'bg-slate-100/50 border-transparent text-slate-400'}`}
               >
                 <span className="text-sm">{level.icon}</span>
                 <span className="text-[8px] font-black uppercase">{level.label}</span>
               </button>
             ))}
          </div>
        </section>

        <section className="flex flex-col gap-3">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
             <Gauge size={10} /> Road Conditions
          </label>
          <div className="grid grid-cols-3 gap-2">
             {[
               { id: 'good', label: 'Smooth', icon: '✨' },
               { id: 'average', label: 'Rough', icon: '🚧' },
               { id: 'poor', label: 'Bumpy', icon: '🕳️' }
             ].map(cond => (
               <button
                 key={cond.id}
                 onClick={() => setRoadCondition(cond.id as any)}
                 className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${roadCondition === cond.id ? 'bg-white border-amber-500 text-amber-600 shadow-sm' : 'bg-slate-100/50 border-transparent text-slate-400'}`}
               >
                 <span className="text-sm">{cond.icon}</span>
                 <span className="text-[8px] font-black uppercase">{cond.label}</span>
               </button>
             ))}
          </div>
        </section>

        <section className="flex flex-col gap-3">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
             <Clock size={10} /> Weather
          </label>
          <div className="grid grid-cols-3 gap-2">
             {[
               { id: 'clear', label: 'Clear', icon: '☀️' },
               { id: 'rainy', label: 'Rainy', icon: '🌧️' },
               { id: 'foggy', label: 'Foggy', icon: '🌫️' }
             ].map(w => (
               <button
                 key={w.id}
                 onClick={() => setWeather(w.id as any)}
                 className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${weather === w.id ? 'bg-white border-blue-400 text-blue-600 shadow-sm' : 'bg-slate-100/50 border-transparent text-slate-400'}`}
               >
                 <span className="text-sm">{w.icon}</span>
                 <span className="text-[8px] font-black uppercase">{w.label}</span>
               </button>
             ))}
          </div>
        </section>

        <section className="flex flex-col gap-3">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
             <CheckCircle2 size={10} /> Seating
          </label>
          <div className="grid grid-cols-3 gap-2">
             {[
               { id: 'available', label: 'Seats', icon: '✅' },
               { id: 'standing_only', label: 'Standing', icon: '🚶' },
               { id: 'full', label: 'No Entry', icon: '❌' }
             ].map(s => (
               <button
                 key={s.id}
                 onClick={() => setSeating(s.id as any)}
                 className={`p-3 rounded-xl border-2 flex flex-col items-center gap-1 transition-all ${seating === s.id ? 'bg-white border-emerald-500 text-emerald-600 shadow-sm' : 'bg-slate-100/50 border-transparent text-slate-400'}`}
               >
                 <span className="text-sm">{s.icon}</span>
                 <span className="text-[8px] font-black uppercase">{s.label}</span>
               </button>
             ))}
          </div>
        </section>
      </div>

      {/* Image Preview / Confirmation Modal */}
      {showPreview && capturedImage && (
        <div className="fixed inset-0 z-50 bg-slate-900/90 flex items-center justify-center p-6 backdrop-blur-sm">
          <div className="bg-white w-full max-w-sm rounded-[2.5rem] overflow-hidden flex flex-col shadow-2xl animate-in fade-in zoom-in duration-300">
            <div className="relative aspect-square bg-slate-100 flex items-center justify-center">
              <img 
                src={capturedImage} 
                alt="Bus Preview" 
                className="w-full h-full object-cover"
              />
              <button 
                onClick={() => setShowPreview(false)}
                className="absolute top-4 right-4 bg-white/20 backdrop-blur-md p-2 rounded-full text-white hover:bg-white/40"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="p-8 pb-10 flex flex-col gap-6 text-center">
              <div>
                <h3 className="text-xl font-black text-slate-900 uppercase tracking-tight">Confirm Bus Photo</h3>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">This helps others identify the bus!</p>
              </div>

              <div className="flex flex-col gap-3">
                <Button 
                  size="xl" 
                  variant="primary" 
                  onClick={handleSubmit}
                  className="bg-emerald-600 shadow-emerald-100"
                >
                  Verify & Ping
                </Button>
                <button 
                  onClick={() => {
                    setCapturedImage(null);
                    setShowPreview(false);
                    triggerCamera();
                  }}
                  className="flex items-center justify-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-red-500 transition-colors"
                >
                  <Trash2 size={14} />
                  Retake Photo
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
