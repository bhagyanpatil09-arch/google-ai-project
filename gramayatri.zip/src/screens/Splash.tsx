/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bus, MapPin, Users, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';
import Button from '../components/ui/Button';

interface SplashProps {
  onStart: () => void;
}

export default function Splash({ onStart }: SplashProps) {
  return (
    <div className="flex flex-col h-full py-8 text-center">
      <div className="flex-1 flex flex-col items-center justify-center gap-8">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', damping: 12 }}
          className="bg-amber-400 p-10 rounded-[3.5rem] shadow-2xl shadow-amber-100 border-b-[12px] border-amber-500 relative"
        >
          <Bus size={80} className="text-amber-950" />
          <motion.div 
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="absolute -top-4 -right-4 bg-primary p-3 rounded-2xl text-white shadow-lg border-4 border-white"
          >
            <MapPin size={24} />
          </motion.div>
        </motion.div>

        <div>
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter mb-4 italic">GRAMAYATRI</h2>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-[0.3em] leading-relaxed max-w-[240px] mx-auto">
            Empowering rural transit through community intelligence
          </p>
        </div>

        <div className="flex flex-col gap-4 w-full px-4">
          <div className="flex items-center gap-3 bg-slate-50 p-4 rounded-3xl border-2 border-slate-100">
             <div className="bg-emerald-100 p-2 rounded-xl text-emerald-600">
                <Users size={20} />
             </div>
             <p className="text-[10px] font-black text-slate-500 text-left uppercase tracking-tight leading-tight">
                Used by <span className="text-emerald-600">500+ passengers</span> in your village corridor
             </p>
          </div>
        </div>
      </div>

      <div className="mt-auto px-4">
        <Button 
          size="xl" 
          variant="primary" 
          onClick={onStart}
          icon={<ChevronRight size={20} />}
          className="shadow-primary/30"
        >
          Get Started
        </Button>
        <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest mt-6">
          v2.5 • Supporting Rural Karnataka
        </p>
      </div>
    </div>
  );
}
