/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState } from 'react';
import { Clock, CheckCircle2, AlertTriangle, ArrowRight, Bus, Map as MapIcon, Timer } from 'lucide-react';
import { BusStatus, BusUpdate } from '../types';
import { busService } from '../lib/services';
import { STOPS_BASE, ROUTES } from '../constants';
import { motion } from 'motion/react';

const RouteMap = ({ latestUpdate, stops }: { latestUpdate: BusUpdate | null, stops: any[] }) => {
  // Map dimensions
  const width = 300;
  const height = 150;
  const padding = 30;

  // Haversine formula to calculate distance between two coordinates in kilometers.
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Radius of Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Calculate total route stats
  const routeStats = (() => {
    let totalDist = 0;
    let totalTime = 0;
    for (let i = 1; i < stops.length; i++) {
      const s1 = stops[i-1];
      const s2 = stops[i];
      totalDist += calculateDistance(s1.lat || 0, s1.lng || 0, s2.lat || 0, s2.lng || 0);
      totalTime += s2.averageTravelMinutes || 0;
    }
    return { dist: totalDist.toFixed(1), time: totalTime };
  })();

  // Find min/max coordinates to scale 
  const lats = stops.map(s => s.lat || 0);
  const lngs = stops.map(s => s.lng || 0);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);

  const getX = (lng: number) => padding + ((lng - minLng) / (maxLng - minLng)) * (width - 2 * padding);
  const getY = (lat: number) => height - (padding + ((lat - minLat) / (maxLat - minLat)) * (height - 2 * padding));

  // Improved Bus Position Calculation
  const getBusPosition = () => {
    if (!latestUpdate) return null;
    
    const currentIndex = stops.findIndex(s => s.id === latestUpdate.stopId);
    if (currentIndex === -1) return null;

    const currentStop = stops[currentIndex];
    
    if (latestUpdate.status === BusStatus.COMING && currentIndex > 0) {
      const prevStop = stops[currentIndex - 1];
      
      // Interpolate position: 70% of the way between previous and current stop
      const progress = 0.7;
      const lat = (prevStop.lat || 0) + ((currentStop.lat || 0) - (prevStop.lat || 0)) * progress;
      const lng = (prevStop.lng || 0) + ((currentStop.lng || 0) - (prevStop.lng || 0)) * progress;
      
      return { x: getX(lng), y: getY(lat) };
    }

    return { x: getX(currentStop.lng || 0), y: getY(currentStop.lat || 0) };
  };

  const busPos = getBusPosition();

  // Dynamic Path Calculation
  const getRoutePaths = () => {
    if (!latestUpdate) return { total: stops.map((s, i) => `${i === 0 ? 'M' : 'L'} ${getX(s.lng || 0)} ${getY(s.lat || 0)}`).join(' '), traveled: '' };

    const currentIndex = stops.findIndex(s => s.id === latestUpdate.stopId);
    if (currentIndex === -1) return { total: stops.map((s, i) => `${i === 0 ? 'M' : 'L'} ${getX(s.lng || 0)} ${getY(s.lat || 0)}`).join(' '), traveled: '' };

    const stopCoords = stops.map(s => ({ x: getX(s.lng || 0), y: getY(s.lat || 0) }));
    
    // Total path string
    const totalPath = stopCoords.map((s, i) => `${i === 0 ? 'M' : 'L'} ${s.x} ${s.y}`).join(' ');

    // Traveled path
    let traveledPath = "";
    if (latestUpdate.status === BusStatus.COMING && currentIndex > 0) {
      // Path to previous stop + segment to current interpolated position
      for (let i = 0; i < currentIndex; i++) {
        traveledPath += `${i === 0 ? 'M' : 'L'} ${stopCoords[i].x} ${stopCoords[i].y} `;
      }
      if (busPos) traveledPath += `L ${busPos.x} ${busPos.y}`;
    } else {
      // Path up to current stop
      for (let i = 0; i <= currentIndex; i++) {
        traveledPath += `${i === 0 ? 'M' : 'L'} ${stopCoords[i].x} ${stopCoords[i].y} `;
      }
    }

    return { total: totalPath, traveled: traveledPath };
  };

  const { total: totalPathD, traveled: traveledPathD } = getRoutePaths();
  const [showDetails, setShowDetails] = useState(false);

  const busInfo = {
    number: "KA-19-F-1234",
    driver: "Ramesh Kumar",
    capacity: "45/55",
    type: "Express Rural"
  };

  return (
    <div className="bg-white p-6 rounded-3xl border-2 border-slate-100 shadow-sm overflow-hidden flex flex-col gap-3 relative">
      <div className="flex justify-between items-end px-1">
        <div className="flex flex-col gap-0.5">
          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Village Connectivity Map</div>
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100 shrink-0">
               <MapIcon size={10} className="text-slate-400" />
               <span className="text-[9px] font-black text-slate-500">{routeStats.dist} KM</span>
            </div>
            <div className="flex items-center gap-1 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-100 shrink-0">
               <Timer size={10} className="text-slate-400" />
               <span className="text-[9px] font-black text-slate-500">{routeStats.time} MIN</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1 mb-1">
           <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
           <span className="text-[8px] font-black text-emerald-500 uppercase tracking-tighter">Live GPS Proxy</span>
        </div>
      </div>

      <div className="relative w-full aspect-[2/1] bg-slate-50 rounded-2xl border border-slate-100 p-2 overflow-hidden">
        {/* Terrain Grids */}
        <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#475569 1px, transparent 1px)', backgroundSize: '12px 12px' }} />
        
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-full relative z-10">
          {/* Background Route line */}
          <path
            d={totalPathD}
            fill="none"
            stroke="#e2e8f0"
            strokeWidth="6"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          
          {/* Traveling Progress Line */}
          <motion.path
            d={traveledPathD}
            fill="none"
            stroke="#f59e0b"
            strokeWidth="6"
            strokeLinecap="round"
            strokeLinejoin="round"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 1 }}
          />

          <path
            d={totalPathD}
            fill="none"
            stroke="#94a3b8"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeDasharray="4 8"
            className="opacity-30"
          />

          {/* Stop Points */}
          {stops.map((stop, i) => {
            const x = getX(stop.lng || 0);
            const y = getY(stop.lat || 0);
            const isDestination = latestUpdate?.stopId === stop.id && latestUpdate.status === BusStatus.COMING;
            const isPassed = stops.findIndex(s => s.id === latestUpdate?.stopId) > i;
            
            return (
              <g key={stop.id}>
                {isDestination && (
                  <motion.circle 
                    cx={x} cy={y} r="10" 
                    fill="none" stroke="#f59e0b" strokeWidth="1"
                    animate={{ scale: [1, 2], opacity: [0.5, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                  />
                )}
                <circle 
                  cx={x} cy={y} r="5" 
                  fill="white" 
                  stroke={isPassed ? "#10b981" : isDestination ? "#f59e0b" : "#cbd5e1"} 
                  strokeWidth="2" 
                />
                <circle 
                  cx={x} cy={y} r="2" 
                  fill={isPassed ? "#10b981" : isDestination ? "#f59e0b" : "#94a3b8"} 
                />
              </g>
            );
          })}

          {/* Animated Bus Icon */}
          {busPos && (
            <motion.g
              initial={busPos}
              animate={busPos}
              transition={{ type: 'spring', damping: 20, stiffness: 60 }}
              onClick={() => setShowDetails(!showDetails)}
              className="cursor-pointer"
            >
              {/* Bus Shadow */}
              <circle cx={busPos.x} cy={busPos.y + 2} r="10" fill="black" opacity="0.1" />
              
              {/* Bus Marker Wrapper with Vibration */}
              <motion.g
                animate={{ y: [0, -1, 0] }}
                transition={{ duration: 0.15, repeat: Infinity }}
              >
                <circle cx={busPos.x} cy={busPos.y} r="12" fill="white" stroke="#f59e0b" strokeWidth="2" />
                <g transform={`translate(${busPos.x - 8}, ${busPos.y - 8}) scale(1)`}>
                  <Bus size={16} className="text-amber-500 stroke-[3]" />
                </g>
              </motion.g>

              {/* Signal Rings */}
              <motion.circle 
                cx={busPos.x} 
                cy={busPos.y} 
                r="18" 
                fill="none" 
                stroke="#f59e0b" 
                strokeWidth="1"
                initial={{ scale: 0.5, opacity: 1 }}
                animate={{ scale: 1.8, opacity: 0 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              />
            </motion.g>
          )}
        </svg>

        {/* Bus Info Tooltip */}
        {showDetails && (
          <motion.div 
            initial={{ opacity: 0, y: 10, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            className="absolute bottom-4 left-4 right-4 bg-white/95 backdrop-blur-md border border-amber-200 rounded-xl p-3 shadow-2xl z-20 flex flex-col gap-2"
          >
            <div className="flex justify-between items-start">
              <div>
                <h4 className="text-[10px] font-black text-slate-900 leading-none mb-0.5">{busInfo.number}</h4>
                <p className="text-[8px] font-bold text-amber-600 uppercase tracking-wider">{busInfo.type}</p>
              </div>
              <button 
                onClick={(e) => { e.stopPropagation(); setShowDetails(false); }}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <ArrowRight size={12} className="rotate-180" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2 mt-1">
              <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                <p className="text-[7px] font-bold text-slate-400 uppercase leading-none mb-1">Driver</p>
                <p className="text-[9px] font-black text-slate-700">{busInfo.driver}</p>
              </div>
              <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-100">
                <p className="text-[7px] font-bold text-slate-400 uppercase leading-none mb-1">Capacity</p>
                <p className="text-[9px] font-black text-slate-700">{busInfo.capacity}</p>
              </div>
              
              {/* Added Real-time community feedback */}
              {latestUpdate?.crowdLevel && (
                <div className="bg-blue-50/50 p-1.5 rounded-lg border border-blue-100">
                  <p className="text-[7px] font-bold text-blue-400 uppercase leading-none mb-1">Crowd</p>
                  <p className="text-[9px] font-black text-blue-700 capitalize">{latestUpdate.crowdLevel}</p>
                </div>
              )}
              {latestUpdate?.roadCondition && (
                <div className="bg-amber-50/50 p-1.5 rounded-lg border border-amber-100">
                  <p className="text-[7px] font-bold text-amber-400 uppercase leading-none mb-1">Road</p>
                  <p className="text-[9px] font-black text-amber-700 capitalize">{latestUpdate.roadCondition}</p>
                </div>
              )}
              {latestUpdate?.weather && (
                <div className="bg-sky-50/50 p-1.5 rounded-lg border border-sky-100">
                  <p className="text-[7px] font-bold text-sky-400 uppercase leading-none mb-1">Weather</p>
                  <p className="text-[9px] font-black text-sky-700 capitalize">{latestUpdate.weather}</p>
                </div>
              )}
              {latestUpdate?.seating && (
                <div className="bg-emerald-50/50 p-1.5 rounded-lg border border-emerald-100">
                  <p className="text-[7px] font-bold text-emerald-400 uppercase leading-none mb-1">Seating</p>
                  <p className="text-[9px] font-black text-emerald-700 capitalize">{latestUpdate.seating.replace('_', ' ')}</p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </div>

      <div className="flex justify-between px-1">
        {stops.map((s, i) => (
          (i === 0 || i === stops.length - 1) && (
            <div key={s.id} className="flex flex-col gap-0.5">
              <span className="text-[7px] font-black text-slate-400 uppercase tracking-tighter">
                {i === 0 ? 'Origin' : 'Terminus'}
              </span>
              <span className="text-[8px] font-black text-slate-600 uppercase tracking-tight leading-none">
                {s.name}
              </span>
            </div>
          )
        ))}
      </div>
    </div>
  );
};

interface RouteViewProps {
  onSelectStop?: (stopName: string) => void;
}

export default function RouteView({ onSelectStop }: RouteViewProps) {
  const [updates, setUpdates] = useState<BusUpdate[]>([]);
  const [selectedRouteId, setSelectedRouteId] = useState(ROUTES[0].id);

  useEffect(() => {
    return busService.subscribeToUpdates((newUpdates) => {
      setUpdates(newUpdates);
    });
  }, []);

  const latestUpdate = updates[0];
  const selectedRoute = ROUTES.find(r => r.id === selectedRouteId) || ROUTES[0];
  const stops = selectedRoute.stops;

  return (
    <div className="flex flex-col gap-6">
      {/* Route Selector */}
      <div className="flex gap-2 p-1 bg-slate-100 rounded-2xl">
         {ROUTES.map(route => (
           <button
             key={route.id}
             onClick={() => setSelectedRouteId(route.id)}
             className={`flex-1 py-3 px-4 rounded-xl text-[10px] font-black uppercase tracking-wider transition-all ${selectedRouteId === route.id ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-400'}`}
           >
             {route.name}
           </button>
         ))}
      </div>

      <RouteMap latestUpdate={latestUpdate} stops={stops} />
      
      {latestUpdate ? (
        <div className="bg-slate-100 p-6 rounded-3xl border-b-4 border-slate-200 text-center flex flex-col items-center">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Last Update</div>
          <p className="text-3xl font-black text-slate-900 leading-tight">
            {stops.find(s => s.id === latestUpdate.stopId)?.name || latestUpdate.stopId}
          </p>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-[0.2em] mt-1">{latestUpdate.status}</p>
          
          <div className="mt-8 p-3 bg-blue-50 rounded-xl text-[10px] text-blue-700 leading-tight border border-blue-100 w-full">
            Reported by <b className="font-black">{latestUpdate.updatedBy}</b><br/>
            {Math.round((Date.now() - latestUpdate.timestamp) / 60000)} mins ago
          </div>
        </div>
      ) : (
        <div className="bg-slate-50 p-8 rounded-3xl border-4 border-dashed border-slate-200 text-center text-slate-400 font-bold uppercase tracking-tighter text-xs">
          Searching for Community Updates...
        </div>
      )}

      <div className="flex flex-col gap-3">
        <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-2">Line Progress</div>
        {stops.map((stop, index) => {
          const stopUpdate = updates.find(u => u.stopId === stop.id);
          const isPassed = stopUpdate?.status === BusStatus.PASSED || stopUpdate?.status === BusStatus.ON_BOARD;
          const isComing = stopUpdate?.status === BusStatus.COMING;
          const isLive = latestUpdate?.stopId === stop.id;

          return (
            <div 
              key={stop.id} 
              onClick={() => onSelectStop?.(stop.name)}
              className={`
                p-4 rounded-xl flex items-center gap-4 transition-all cursor-pointer active:scale-95
                ${isLive ? 'bg-amber-50 border-2 border-amber-200 shadow-lg shadow-amber-50' : 'bg-white border border-slate-100'}
                ${isPassed ? 'opacity-40' : ''}
              `}
            >
              <div className={`
                w-4 h-4 flex-shrink-0
                ${isPassed ? 'text-green-500' : isComing ? 'text-amber-500 animate-bounce' : 'text-slate-200'}
              `}>
                <Bus size={16} className="stroke-[3]" />
              </div>
              
              <div className="flex-1">
                <div className="flex justify-between items-center">
                  <h4 className="text-xs font-black text-slate-900">{stop.name}</h4>
                  <span className={`
                    text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded
                    ${isPassed ? 'text-green-600' : isLive ? 'text-amber-600 italic' : 'text-slate-400'}
                  `}>
                    {isPassed ? 'Passed' : isLive ? 'Arriving' : 'SCHEDULED'}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
