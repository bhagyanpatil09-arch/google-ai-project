/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, Phone, MapPin, Lock, ChevronRight, ShieldCheck } from 'lucide-react';
import Button from '../components/ui/Button';

interface RegisterProps {
  onNavigate: (screen: any) => void;
}

type Step = 'details' | 'otp';

export default function Register({ onNavigate }: RegisterProps) {
  const [step, setStep] = useState<Step>('details');
  const [formData, setFormData] = useState({
    name: '',
    mobile: '',
    village: '',
    password: ''
  });
  const [otp, setOtp] = useState('');

  const handleRegisterClick = () => {
    if (formData.mobile) {
      setStep('otp');
    } else {
      alert("Please enter a mobile number");
    }
  };

  const handleOtpVerify = (otpToVerify: string = otp) => {
    if (otpToVerify.length === 4) {
      onNavigate('home');
    } else {
      alert("Please enter a valid 4-digit OTP");
    }
  };

  const InputField = ({ icon: Icon, label, placeholder, type = "text", value, onChange }: any) => (
    <div className="flex flex-col gap-2">
      <label className="text-xs font-black text-slate-500 uppercase tracking-widest px-2">{label}</label>
      <div className="relative group">
        <div className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-primary transition-colors">
          <Icon size={20} />
        </div>
        <input 
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          className="w-full p-6 pl-16 text-lg font-black bg-white border-[4px] border-slate-100 rounded-[2rem] outline-none focus:border-primary focus:ring-4 focus:ring-amber-50 transition-all shadow-sm placeholder:text-slate-200"
        />
      </div>
    </div>
  );

  if (step === 'otp') {
    return (
      <div className="flex flex-col gap-8 py-8 h-full justify-center">
        <div className="text-center">
          <div className="bg-emerald-600 text-white w-20 h-20 rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-emerald-100 rotate-2 border-b-8 border-emerald-700">
            <ShieldCheck size={40} />
          </div>
          <h2 className="text-2xl font-black text-slate-900 mb-2">Verify Phone</h2>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest leading-loose">
            Enter the 4-digit code sent to<br/>
            <span className="text-emerald-600 font-black text-sm">+91 {formData.mobile}</span>
          </p>
        </div>

        <div className="flex justify-center gap-3 py-4">
          {[0, 1, 2, 3].map((i) => (
            <input
              key={i}
              id={`otp-${i}`}
              type="tel"
              maxLength={1}
              autoFocus={i === 0}
              value={otp[i] || ''}
              onChange={(e) => {
                const val = e.target.value;
                if (!/^\d*$/.test(val)) return;
                
                const newOtp = otp.split('');
                newOtp[i] = val.slice(-1);
                const finalOtp = newOtp.join('');
                setOtp(finalOtp);

                // Auto-focus next
                if (val && i < 3) {
                  document.getElementById(`otp-${i + 1}`)?.focus();
                }
                
                // Auto-submit if full
                if (finalOtp.length === 4 && i === 3) {
                  setTimeout(() => handleOtpVerify(finalOtp), 300);
                }
              }}
              onKeyDown={(e) => {
                if (e.key === 'Backspace' && !otp[i] && i > 0) {
                  document.getElementById(`otp-${i - 1}`)?.focus();
                }
              }}
              className="w-16 h-20 text-3xl text-center font-black bg-white border-[4px] border-slate-100 rounded-2xl outline-none focus:border-emerald-500 focus:ring-8 focus:ring-emerald-50 transition-all shadow-sm"
            />
          ))}
        </div>

        <div className="flex flex-col gap-4">
          <Button 
            size="xl" 
            variant="primary" 
            onClick={() => handleOtpVerify(otp)}
            disabled={otp.length < 4}
            className={otp.length === 4 ? 'bg-emerald-600 shadow-emerald-100' : ''}
          >
            Verify & Finish
          </Button>
          <button 
            onClick={() => {
              setStep('details');
              setOtp('');
            }}
            className="text-[10px] font-black text-slate-400 uppercase tracking-widest hover:text-primary"
          >
            Wrong number? <span className="text-primary underline">Go Back</span>
          </button>
        </div>

        <div className="mt-auto text-center">
          <p className="text-[10px] font-bold text-slate-300 uppercase tracking-tighter">
            Didn't receive code? <span className="text-slate-400 underline">Send again</span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-6 py-2 h-full">
      <div className="text-center mb-2">
        <h2 className="text-2xl font-black text-primary">Create Account</h2>
        <p className="text-xs font-bold text-slate-400">Join the passenger community</p>
      </div>

      <div className="flex flex-col gap-4 overflow-y-auto pr-2 scrollbar-hide">
        <InputField 
          icon={User} 
          label="Full Name" 
          placeholder="Enter your name"
          value={formData.name}
          onChange={(e: any) => setFormData({...formData, name: e.target.value})}
        />
        <InputField 
          icon={Phone} 
          label="Mobile Number" 
          placeholder="9988776655"
          type="tel"
          value={formData.mobile}
          onChange={(e: any) => setFormData({...formData, mobile: e.target.value})}
        />
        <InputField 
          icon={MapPin} 
          label="Village Name" 
          placeholder="Your home village"
          value={formData.village}
          onChange={(e: any) => setFormData({...formData, village: e.target.value})}
        />
        <InputField 
          icon={Lock} 
          label="Set Password" 
          placeholder="••••••••"
          type="password"
          value={formData.password}
          onChange={(e: any) => setFormData({...formData, password: e.target.value})}
        />
      </div>

      <div className="mt-auto pt-4 flex flex-col gap-3">
        <Button 
          size="xl" 
          variant="secondary" 
          icon={<ChevronRight size={20} />}
          onClick={handleRegisterClick}
        >
          Get OTP
        </Button>
        <Button 
          size="xl" 
          variant="outline" 
          onClick={() => onNavigate('login')}
        >
          Back to Login
        </Button>
        <button 
          onClick={() => onNavigate('login')}
          className="w-full mt-2 text-center text-xs font-black text-slate-400 uppercase tracking-widest hover:text-primary transition-colors"
        >
          Already have an account? <span className="text-primary underline">Login</span>
        </button>
      </div>
    </div>
  );
}
