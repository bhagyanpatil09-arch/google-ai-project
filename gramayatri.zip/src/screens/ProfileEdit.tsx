/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { User, Phone, MapPin, Camera, Save, CheckCircle2 } from 'lucide-react';
import Button from '../components/ui/Button';
import { motion, AnimatePresence } from 'motion/react';

interface ProfileEditProps {
  onSave: () => void;
}

export default function ProfileEdit({ onSave }: ProfileEditProps) {
  const [isSaving, setIsSaving] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [formData, setFormData] = useState({
    name: "Sunil Kumar",
    phone: "+91 98765 43210",
    village: "Ramnagar",
    occupation: "Agricultural Worker"
  });

  const handleSave = () => {
    setIsSaving(true);
    // Simulate API call
    setTimeout(() => {
      setIsSaving(false);
      setShowSuccess(true);
      setTimeout(() => {
        setShowSuccess(false);
        onSave();
      }, 1500);
    }, 1000);
  };

  const InputWrapper = ({ icon: Icon, label, value, onChange, placeholder }: any) => (
    <div className="flex flex-col gap-2">
      <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-2">{label}</label>
      <div className="flex items-center gap-4 p-4 bg-white rounded-3xl border-2 border-slate-100 focus-within:border-primary transition-all shadow-sm">
        <Icon size={18} className="text-slate-400" />
        <input 
          type="text" 
          value={value} 
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          className="flex-1 bg-transparent border-none outline-none text-slate-900 font-bold text-sm placeholder:text-slate-300" 
        />
      </div>
    </div>
  );

  return (
    <div className="flex flex-col gap-8 h-full pb-10">
      <AnimatePresence>
        {showSuccess && (
          <motion.div 
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-emerald-500 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3"
          >
            <CheckCircle2 size={18} />
            <span className="text-xs font-black uppercase tracking-widest">Profile Updated</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Avatar Section */}
      <section className="flex flex-col items-center gap-4 mt-4">
        <div className="relative">
          <div className="w-32 h-32 rounded-[3rem] bg-indigo-100 border-4 border-white shadow-xl flex items-center justify-center overflow-hidden">
            <User size={64} className="text-indigo-400" />
          </div>
          <button className="absolute -bottom-2 -right-2 p-3 bg-primary text-white rounded-2xl shadow-lg border-4 border-slate-50 hover:scale-110 transition-transform">
            <Camera size={18} />
          </button>
        </div>
        <div className="text-center">
          <h3 className="text-lg font-black text-slate-900">Edit Your Identity</h3>
          <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest leading-none mt-1">Community Level: Top Contributor</p>
        </div>
      </section>

      {/* Form Fields */}
      <div className="flex flex-col gap-5">
        <InputWrapper 
          icon={User} 
          label="Full Name" 
          value={formData.name} 
          onChange={(v: string) => setFormData({...formData, name: v})}
          placeholder="Enter your name"
        />
        <InputWrapper 
          icon={Phone} 
          label="Phone Number" 
          value={formData.phone} 
          onChange={(v: string) => setFormData({...formData, phone: v})}
          placeholder="Your contact number"
        />
        <div className="flex flex-col gap-2">
          <label className="text-[9px] font-black text-slate-400 uppercase tracking-[0.2em] px-2 text-left">Your Village</label>
          <div className="flex items-center gap-4 p-4 bg-white rounded-3xl border-2 border-slate-100 focus-within:border-primary transition-all shadow-sm">
            <MapPin size={18} className="text-slate-400" />
            <select 
              value={formData.village}
              onChange={(e) => setFormData({...formData, village: e.target.value})}
              className="flex-1 bg-transparent border-none outline-none text-slate-900 font-bold text-sm appearance-none"
            >
              <option>Ramnagar</option>
              <option>Shantipur</option>
              <option>Lakshmipura</option>
              <option>Hanumanthalli</option>
              <option>Kaverinagar</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-amber-50 p-6 rounded-3xl border-2 border-amber-100 shadow-sm mt-2">
        <div className="flex items-start gap-4">
          <div className="bg-amber-400 p-2 rounded-xl text-white shrink-0">
            <CheckCircle2 size={16} />
          </div>
          <div>
            <h5 className="text-[10px] font-black text-amber-900 uppercase mb-1">Impact Check</h5>
            <p className="text-[9px] font-bold text-amber-700 leading-relaxed uppercase tracking-tight">
              Your real name helps fellow villagers trust your bus updates. Verified profiles get 2x more visibility.
            </p>
          </div>
        </div>
      </div>

      <div className="mt-auto">
        <Button 
          variant="primary" 
          size="xl" 
          onClick={handleSave}
          disabled={isSaving}
          className="shadow-primary/30"
          icon={isSaving ? null : <Save size={18} />}
        >
          {isSaving ? "Syncing Data..." : "Save Changes"}
        </Button>
      </div>
    </div>
  );
}
