/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Bus, ChevronDown, MapPin, Info, Search, X } from 'lucide-react';
import Button from '../components/ui/Button';
import { STOPS_BASE } from '../constants';

interface HomeProps {
  onNavigate: (screen: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const [searchTerm, setSearchTerm] = useState('');
  
  const filteredStops = searchTerm.trim() 
    ? STOPS_BASE.filter(stop => 
        stop.name.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : [];

  return (
    <div className="flex flex-col gap-6 h-full">
      {/* Village Selection Dropdown */}
      <section className="flex flex-col gap-2">
        <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-2">
          Your Current Village/Stop
        </label>
        <div className="relative group">
          <select 
            className="w-full p-5 text-sm font-black bg-white border-[3px] border-slate-900 rounded-[1.5rem] appearance-none outline-none focus:ring-4 focus:ring-amber-100 transition-all cursor-pointer"
            defaultValue="Main Village Square"
          >
            <option>City Terminal</option>
            <option>Village A Crossing</option>
            <option>Main Village Square</option>
            <option>Village C Bridge</option>
          </select>
          <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-900">
            <ChevronDown size={20} className="stroke-[3]" />
          </div>
        </div>
      </section>

      {/* Global Search Bar */}
      <section className="flex flex-col gap-2">
        <div className="relative">
          <div className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400">
            <Search size={18} />
          </div>
          <input 
            type="text"
            placeholder="SEARCH STOPS OR ROUTES..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-14 pr-12 py-4 bg-slate-50 border-2 border-slate-100 rounded-2xl text-[10px] font-black uppercase tracking-widest outline-none focus:border-primary transition-all placeholder:text-slate-300"
          />
          {searchTerm && (
            <button 
              onClick={() => setSearchTerm('')}
              className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
            >
              <X size={16} />
            </button>
          )}
        </div>

        {/* Search Results Dropdown */}
        {searchTerm && (
          <div className="bg-white border-2 border-slate-100 rounded-2xl shadow-xl max-h-48 overflow-y-auto z-30 flex flex-col divide-y divide-slate-50">
            {filteredStops.length > 0 ? (
              filteredStops.map(stop => (
                <button 
                  key={stop.id}
                  onClick={() => onNavigate('route-view')}
                  className="flex items-center gap-3 p-4 hover:bg-slate-50 transition-colors text-left"
                >
                  <div className="p-2 bg-amber-100 rounded-lg text-amber-600">
                    <MapPin size={14} />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[11px] font-black text-slate-900 uppercase">{stop.name}</span>
                    <span className="text-[8px] font-bold text-slate-400 uppercase">Bus Stop</span>
                  </div>
                </button>
              ))
            ) : (
              <div className="p-6 text-center">
                <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest italic">No matching villages found</p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Main Branding Section */}
      <div className="text-center py-4">
        <div className="bg-amber-400 p-8 rounded-[2.5rem] inline-block mb-4 shadow-2xl shadow-amber-100 border-b-8 border-amber-500 transform -rotate-2">
          <Bus size={64} className="text-amber-950" />
        </div>
        <p className="text-slate-500 font-bold uppercase tracking-[0.2em] text-[11px]">
          Community Powered Live Updates
        </p>
      </div>

      {/* Primary Action Buttons */}
      <div className="flex flex-col gap-5 mt-4">
        <Button 
          id="check-status-btn"
          size="xl" 
          variant="primary"
          onClick={() => onNavigate('route-view')}
          className="!h-24 shadow-2xl"
        >
          <div className="flex items-center gap-4">
            <MapPin size={24} className="text-accent" />
            <span className="text-lg">Check Bus Status</span>
          </div>
        </Button>

        <Button 
          id="update-info-btn"
          size="xl" 
          variant="secondary"
          onClick={() => onNavigate('live-update')}
          className="!h-24 shadow-2xl"
        >
          <div className="flex items-center gap-4">
            <Info size={24} />
            <span className="text-lg">Update Bus Info</span>
          </div>
        </Button>
      </div>

      {/* Footer Info */}
      <div className="mt-auto pt-6 border-t border-slate-100 flex justify-between items-center px-2">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">System Live</span>
        </div>
        <div className="text-[10px] font-black text-slate-400 uppercase tracking-tighter">
          Low Data Mode Active 📶
        </div>
      </div>
    </div>
  );
}
