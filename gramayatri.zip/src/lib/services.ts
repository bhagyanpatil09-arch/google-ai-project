/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { 
  collection, 
  addDoc, 
  query, 
  orderBy, 
  limit, 
  onSnapshot,
  doc,
  getDoc 
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { BusUpdate, BusStatus, Alert } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

let errorListener: ((message: string) => void) | null = null;

export const onServiceError = (callback: (message: string) => void) => {
  errorListener = callback;
  return () => { errorListener = null; };
};

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errorMessage = error instanceof Error ? error.message : String(error);
  
  const errInfo: FirestoreErrorInfo = {
    error: errorMessage,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  }
  
  console.error('Firestore Error: ', JSON.stringify(errInfo));

  // User friendly mapping
  let friendlyMessage = 'Something went wrong. Please try again.';
  
  if (errorMessage.includes('permission-denied') || errorMessage.includes('insufficient permissions')) {
    friendlyMessage = 'You don\'t have permission to do this. Are you signed in?';
  } else if (operationType === OperationType.WRITE || operationType === OperationType.CREATE) {
    friendlyMessage = 'Could not post your update. Please check your connection.';
  } else if (operationType === OperationType.GET || operationType === OperationType.LIST) {
    friendlyMessage = 'Could not load the latest data. Please refresh.';
  }

  if (errorListener) {
    errorListener(friendlyMessage);
  }

  throw new Error(JSON.stringify(errInfo));
}

export const busService = {
  async submitUpdate(
    stopId: string, 
    status: BusStatus, 
    userName: string = 'Anonymous User',
    extras?: { 
      crowdLevel?: 'low' | 'medium' | 'high'; 
      roadCondition?: 'good' | 'average' | 'poor';
      weather?: 'clear' | 'rainy' | 'foggy';
      seating?: 'available' | 'standing_only' | 'full';
    }
  ) {
    const path = 'updates';
    try {
      await addDoc(collection(db, path), {
        stopId,
        status,
        timestamp: Date.now(),
        updatedBy: userName,
        creatorId: auth.currentUser?.uid,
        ...extras
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  async submitAlert(type: Alert['type'], title: string, desc: string, userName: string = 'Anonymous User') {
    const path = 'alerts';
    try {
      await addDoc(collection(db, path), {
        type,
        title,
        desc,
        timestamp: Date.now(),
        updatedBy: userName,
        creatorId: auth.currentUser?.uid
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
  },

  subscribeToUpdates(callback: (updates: BusUpdate[]) => void) {
    const path = 'updates';
    const q = query(
      collection(db, path),
      orderBy('timestamp', 'desc'),
      limit(20)
    );

    return onSnapshot(q, (snapshot) => {
      const updates = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as BusUpdate[];
      callback(updates);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
  },

  subscribeToAlerts(callback: (alerts: Alert[]) => void) {
    const path = 'alerts';
    const q = query(
      collection(db, path),
      orderBy('timestamp', 'desc'),
      limit(10)
    );

    return onSnapshot(q, (snapshot) => {
      const alerts = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Alert[];
      callback(alerts);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
  }
};

export const userService = {
  async getProfile(uid: string) {
    const path = `users/${uid}`;
    try {
      const docRef = doc(db, 'users', uid);
      const snap = await getDoc(docRef);
      if (snap.exists()) {
        return snap.data();
      }
      return null;
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, path);
      return null;
    }
  }
};
