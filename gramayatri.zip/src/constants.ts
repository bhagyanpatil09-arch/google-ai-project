/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BusStop } from './types';

export const STOPS_BASE: BusStop[] = [
  { id: 'shantipur', name: 'Shantipur', order: 1, averageTravelMinutes: 0, lat: 12.9716, lng: 77.5946 },
  { id: 'ramnagar', name: 'Ramnagar', order: 2, averageTravelMinutes: 15, lat: 12.9816, lng: 77.6046 },
  { id: 'lakshmipura', name: 'Lakshmipura', order: 3, averageTravelMinutes: 10, lat: 12.9916, lng: 77.6146 },
  { id: 'hanumanthalli', name: 'Hanumanthalli', order: 4, averageTravelMinutes: 12, lat: 13.0016, lng: 77.6246 },
  { id: 'kaverinagar', name: 'Kaverinagar', order: 5, averageTravelMinutes: 15, lat: 13.0116, lng: 77.6346 },
];

export const STOPS_MOUNTAIN: BusStop[] = [
  { id: 'mount_base', name: 'Mountain Base', order: 1, averageTravelMinutes: 0, lat: 13.1016, lng: 77.7046 },
  { id: 'hill_top', name: 'Hill Top', order: 2, averageTravelMinutes: 25, lat: 13.1216, lng: 77.7246 },
  { id: 'valley_view', name: 'Valley View', order: 3, averageTravelMinutes: 15, lat: 13.1416, lng: 77.7446 },
  { id: 'forest_end', name: 'Forest End', order: 4, averageTravelMinutes: 20, lat: 13.1616, lng: 77.7646 },
];

export const ROUTES = [
  { id: 'express', name: 'Express Rural', stops: STOPS_BASE },
  { id: 'mountain', name: 'Mountain Route', stops: STOPS_MOUNTAIN }
];
