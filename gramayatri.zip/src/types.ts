/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BusStop {
  id: string;
  name: string;
  order: number;
  averageTravelMinutes: number; // Time from previous stop
  lat?: number;
  lng?: number;
}

export interface Route {
  id: string;
  name: string; // e.g., "City to Village X"
  stops: BusStop[];
}

export enum BusStatus {
  COMING = 'COMING',
  PASSED = 'PASSED',
  DELAYED = 'DELAYED',
  CANCELLED = 'CANCELLED',
  ON_BOARD = 'ON_BOARD'
}

export interface BusUpdate {
  id: string;
  stopId: string;
  timestamp: number;
  status: BusStatus;
  updatedBy: string;
  crowdLevel?: 'low' | 'medium' | 'high';
  roadCondition?: 'good' | 'average' | 'poor';
  weather?: 'clear' | 'rainy' | 'foggy';
  seating?: 'available' | 'standing_only' | 'full';
}

export interface Alert {
  id: string;
  type: 'delay' | 'cancel' | 'breakdown';
  title: string;
  desc: string;
  timestamp: number;
  updatedBy: string;
}

export interface LiveStatus {
  lastUpdate: BusUpdate | null;
  estimatedArrivalMinutes: number | null;
}
