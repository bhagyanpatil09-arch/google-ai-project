/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, User } from 'lucide-react';

interface LayoutProps {
  title: string;
  onBack?: () => void;
  onSettings?: () => void;
  children: React.ReactNode;
}

export default function Layout({ title, onBack, onSettings, children }: LayoutProps) {
  return (
    <div className="flex flex-col min-h-screen bg-bg p-4 flex items-center justify-center font-sans">
      <div className="w-full max-w-sm h-[800px] bg-white rounded-[2.5rem] border-[8px] border-primary shadow-[0_35px_60px_-15px_rgba(0,0,0,0.3)] overflow-hidden flex flex-col relative">
        {/* Notch */}
        <div className="h-5 w-1/3 bg-primary absolute top-0 left-1/2 -translate-x-1/2 rounded-b-2xl z-20"></div>

        {/* Header */}
        <header className="bg-primary text-white pt-8 pb-6 px-6 shadow-md flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 min-w-[40px]">
            {onBack && (
              <button 
                id="back-button"
                onClick={onBack}
                className="p-2 hover:bg-white/10 rounded-full transition-colors flex items-center justify-center"
                aria-label="Go back"
              >
                <ChevronLeft size={24} />
              </button>
            )}
          </div>
          
          <h1 className="text-xl font-black uppercase tracking-widest flex-1 text-center whitespace-nowrap overflow-hidden text-ellipsis">{title}</h1>
          
          <div className="flex items-center gap-2 min-w-[40px] justify-end">
            {onSettings && (
              <button 
                id="settings-button"
                onClick={onSettings}
                className="p-2 hover:bg-white/10 rounded-full transition-colors flex items-center justify-center"
                aria-label="Settings"
              >
                <User size={24} />
              </button>
            )}
          </div>
        </header>

        {/* Main Content */}
        <main className="flex-1 p-6 relative overflow-y-auto scrollbar-hide">
          <AnimatePresence mode="wait">
            <motion.div
              key={title}
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.02 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
