import React from 'react';
import { AlertTriangle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface SnackbarProps {
  message: string | null;
  onClose: () => void;
}

export default function Snackbar({ message, onClose }: SnackbarProps) {
  return (
    <AnimatePresence>
      {message && (
        <motion.div
           initial={{ opacity: 0, y: 50, scale: 0.9 }}
           animate={{ opacity: 1, y: 0, scale: 1 }}
           exit={{ opacity: 0, y: 20, scale: 0.9 }}
           className="fixed bottom-24 left-4 right-4 z-[100] flex justify-center pointer-events-none"
        >
          <div className="bg-slate-900 text-white px-5 py-4 rounded-2xl shadow-2xl flex items-center gap-4 border border-white/10 backdrop-blur-lg pointer-events-auto max-w-sm w-full">
            <div className="bg-amber-500 p-2 rounded-xl text-slate-900 shrink-0">
               <AlertTriangle size={18} />
            </div>
            <div className="flex-1">
              <p className="text-[11px] font-black uppercase tracking-widest text-amber-500 mb-0.5">System Alert</p>
              <p className="text-xs font-bold leading-snug">{message}</p>
            </div>
            <button 
              onClick={onClose}
              className="p-1 hover:bg-white/10 rounded-lg transition-colors text-slate-400 hover:text-white"
            >
              <X size={16} />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
