/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';

interface ButtonProps {
  variant?: 'primary' | 'secondary' | 'outline' | 'alert';
  size?: 'lg' | 'xl';
  icon?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  onClick?: any;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  id?: string;
}

export default function Button({ 
  children, 
  variant = 'primary', 
  size = 'lg', 
  icon,
  className = '',
  ...props 
}: ButtonProps) {
  const variants = {
    primary: 'bg-primary text-white shadow-xl shadow-slate-200 uppercase tracking-widest',
    secondary: 'bg-accent text-primary shadow-xl shadow-amber-100 uppercase tracking-widest font-black',
    outline: 'bg-white border-[3px] border-primary text-primary active:bg-slate-50',
    alert: 'bg-danger text-white shadow-xl shadow-red-100 uppercase tracking-widest',
  };

  const sizes = {
    lg: 'p-4 text-xs font-bold rounded-2xl',
    xl: 'p-6 text-sm font-black rounded-2xl',
  };

  return (
    <motion.button
      whileHover={{ scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      className={`
        w-full flex items-center justify-center gap-3
        transition-all duration-200
        ${variants[variant]}
        ${sizes[size]}
        ${className}
      `}
      {...props}
    >
      {icon && <span className="flex-shrink-0">{icon}</span>}
      <span>{children}</span>
    </motion.button>
  );
}
