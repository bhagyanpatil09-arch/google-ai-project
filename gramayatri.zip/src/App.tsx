/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import Layout from './components/ui/Layout';
import Home from './screens/Home';
import RouteView from './screens/RouteView';
import LiveUpdate from './screens/LiveUpdate';
import Alerts from './screens/Alerts';
import Register from './screens/Register';
import Confirmation from './screens/Confirmation';
import LiveStatus from './screens/LiveStatus';
import Splash from './screens/Splash';
import ProjectFlow from './screens/ProjectFlow';
import DemoDataset from './screens/DemoDataset';
import Settings from './screens/Settings';
import ProfileEdit from './screens/ProfileEdit';
import { auth, db } from './lib/firebase';
import { onAuthStateChanged, User } from 'firebase/auth';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { onServiceError } from './lib/services';
import Snackbar from './components/ui/Snackbar';

type Screen = 'splash' | 'home' | 'route-view' | 'live-update' | 'alerts' | 'register' | 'confirmation' | 'live-status' | 'project-flow' | 'demo-dataset' | 'settings' | 'profile-edit';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('splash');
  const [selectedStop, setSelectedStop] = useState<string>('');
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    const unsubError = onServiceError((msg) => {
      setErrorMsg(msg);
      // Auto hide after 5 seconds
      setTimeout(() => setErrorMsg(null), 5000);
    });

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      setLoading(false);

      if (firebaseUser) {
        // Ensure user profile exists in Firestore
        const userRef = doc(db, 'users', firebaseUser.uid);
        const userSnap = await getDoc(userRef);

        if (!userSnap.exists()) {
          await setDoc(userRef, {
            uid: firebaseUser.uid,
            name: firebaseUser.displayName || 'Anonymous Villager',
            email: firebaseUser.email,
            role: 'user',
            createdAt: serverTimestamp()
          }, { merge: true });
        }

        if (currentScreen === 'splash' || currentScreen === 'register') {
          setCurrentScreen('home');
        }
      }
    });

    return () => {
      unsubscribe();
      unsubError();
    };
  }, [currentScreen]);

  const getTitle = () => {
    switch (currentScreen) {
      case 'splash': return 'GramaYatri';
      case 'home': return 'GramaYatri';
      case 'route-view': return 'Bus Status';
      case 'live-update': return 'Share Info';
      case 'alerts': return 'Alerts';
      case 'register': return 'Join Us';
      case 'confirmation': return 'Success';
      case 'live-status': return 'Live Arrival';
      case 'project-flow': return 'App Flow';
      case 'demo-dataset': return 'Demo Data';
      case 'settings': return 'Settings';
      case 'profile-edit': return 'Edit Profile';
      default: return 'GramaYatri';
    }
  };

  const handleBack = () => {
    switch (currentScreen) {
      case 'register':
        setCurrentScreen('splash');
        break;
      case 'project-flow':
      case 'demo-dataset':
        setCurrentScreen('home');
        break;
      case 'settings':
        setCurrentScreen('home');
        break;
      case 'profile-edit':
        setCurrentScreen('settings');
        break;
      case 'live-status':
        setCurrentScreen('route-view');
        break;
      case 'route-view':
      case 'live-update':
      case 'alerts':
        setCurrentScreen('home');
        break;
      default:
        break;
    }
  };

  const showBackButton = !['splash', 'home', 'confirmation'].includes(currentScreen);
  const showSettingsButton = ['home', 'route-view', 'alerts', 'live-status'].includes(currentScreen);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-bg">
        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <Layout 
      title={getTitle()} 
      onBack={showBackButton ? handleBack : undefined}
      onSettings={showSettingsButton ? () => setCurrentScreen('settings') : undefined}
    >
      {currentScreen === 'splash' && (
        <Splash onStart={() => setCurrentScreen('home')} />
      )}
      {currentScreen === 'register' && (
        <Register onNavigate={(screen) => setCurrentScreen(screen as Screen)} />
      )}
      {currentScreen === 'home' && (
        <Home onNavigate={(screen) => setCurrentScreen(screen as Screen)} />
      )}
      {currentScreen === 'route-view' && (
        <RouteView onSelectStop={(stop) => {
          setSelectedStop(stop);
          setCurrentScreen('live-status');
        }} />
      )}
      {currentScreen === 'live-status' && (
        <LiveStatus 
          stopName={selectedStop} 
          onUpdateClick={() => setCurrentScreen('live-update')} 
        />
      )}
      {currentScreen === 'live-update' && (
        <LiveUpdate onComplete={() => setCurrentScreen('confirmation')} />
      )}
      {currentScreen === 'confirmation' && (
        <Confirmation onDone={() => setCurrentScreen('home')} />
      )}
      {currentScreen === 'alerts' && (
        <Alerts />
      )}
      {currentScreen === 'project-flow' && (
        <ProjectFlow />
      )}
      {currentScreen === 'demo-dataset' && (
        <DemoDataset />
      )}
      {currentScreen === 'settings' && (
        <Settings 
          onEditProfile={() => setCurrentScreen('profile-edit')}
        />
      )}
      {currentScreen === 'profile-edit' && (
        <ProfileEdit onSave={() => setCurrentScreen('settings')} />
      )}
      <Snackbar message={errorMsg} onClose={() => setErrorMsg(null)} />
    </Layout>
  );
}
