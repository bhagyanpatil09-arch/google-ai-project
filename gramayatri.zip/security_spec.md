# Firestore Security Specification - GramaYatri

## Data Invariants
1. A `BusUpdate` must refer to a valid `stopId`.
2. A user can only edit their own profile.
3. Updates and Alerts must have a `timestamp` and `updatedBy` matching the current user.

## The Dirty Dozen Payloads (Target: Access Control & Integrity)

1. **Identity Theft (Profile):** User A trying to write to `/users/UserB`.
2. **Shadow Field (Profile):** User A adding `isAdmin: true` to their own profile.
3. **Ghost Update (BusUpdate):** User A creating an update with `updatedBy: UserB`.
4. **Time Spoofing:** User A creating an update with a `timestamp` from 2 hours in the future.
5. **Path Poisoning:** Creating an update with a document ID that is 2KB of junk.
6. **State Skip:** Updating a `PASSED` status back to `COMING` (if we had state transition rules).
7. **Unauthenticated Write:** Writing to `updates` without being logged in.
8. **Malicious Payload:** Injecting a 1MB string into the `reporterName` field.
9. **Orphaned Update:** Creating an update for a non-existent stop ID (checked against `isValidId`).
10. **Resource Exhaustion:** Creating 10,000 updates in one second (limited by Firestore server-side, but rules should restrict).
11. **PII Leak:** An unauthenticated user trying to read all `users` collection.
12. **System Override:** A regular user attempting to delete an `Alert` created by another user.

## Verification
Rules will be tested against these principles.
